<template>
    <v-container>
        <v-flex xs2>
            <h3> {{ this.ator.nome }} </h3>
        </v-flex>
        <v-flex xs10>
            <v-layout row wrap v-if="filmes.length > 0">
                <v-data-table
                    :headers="headers"
                    :items="filmes"
                >
                    <template v-slot:no-data>
                        <v-alert :value="true" color="error" icon="warning">
                            Não foi possível apresentar uma lista dos filmes...
                        </v-alert>
                    </template>

                    <template v-slot:items="props">
                        <tr>
                            <td @click="rowClicked(props.item.f.split('#')[1])" class="subheading">{{ props.item.ftit }}</td>
                            <td class="subheading">{{ props.item.f.split('#')[1] }}</td>
                        </tr>
                    </template>
                </v-data-table>
            </v-layout>
            <v-layout row wrap v-else>
                <v-flex xs12>
                    <p>Sem filmes associados...</p>
                </v-flex>
            </v-layout>
        </v-flex>
    </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://cinema.di.uminho.pt'

export default {
  props: ['idAtor'],
  data: () => ({
    headers: [
      { text: 'Nome', align: 'left', sortable: true, value: 'ftit', class: 'title' },
      { text: 'Identificador', sortable: false, value: 'f', class: 'title' }
    ],
    ator: {},
    filmes: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/atores/' + this.idAtor)
      this.ator = response.data[0]
      console.log(this.ator.nome)
      response = await axios.get(lhost + '/atores/' + this.idAtor + '/filmes')
      this.filmes = response.data
    } catch (e) {
      return (e)
    }
  },
  methods: {
    rowClicked: function (id) {
      this.$router.push('/filmes/' + id)
    }
  }
}
</script>
