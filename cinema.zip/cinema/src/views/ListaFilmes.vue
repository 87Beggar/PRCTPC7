<template>
  <Filmes />
</template>

<script>
  import Filmes from '@/components/Filmes'  //@ é um alias para src

  export default {
    components: {
      Filmes
    }
  }
</script>
